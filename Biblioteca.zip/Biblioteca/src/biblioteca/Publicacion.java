/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

import java.util.Objects;

/**
 *
 * @author Milee
 */
public abstract class Publicacion {
    protected String titulo;
    protected int anioPublicacion;

    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }
    
    public abstract void mostrarInfo();
    
    
    @Override
    public boolean equals(Object o) {
    if (this == o) {
        return true; 
    }
    if (o == null || o.getClass() != this.getClass()) {
        return false; 
    }
    Publicacion publicacion = (Publicacion) o; // Hacemos el casting
    return titulo.equals(publicacion.titulo) && anioPublicacion == publicacion.anioPublicacion; // Comparamos los atributos
}

    @Override
    public int hashCode() {
        return Objects.hash(titulo,anioPublicacion);
    }
}