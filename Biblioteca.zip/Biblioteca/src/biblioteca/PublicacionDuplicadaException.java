/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package biblioteca;

/**
 *
 * @author Milee
 */
public class PublicacionDuplicadaException extends Exception {
    public static final String MESSAGE = "Ya existe esa publicacion";
    
    public PublicacionDuplicadaException(){
        super(MESSAGE);
    }
}
