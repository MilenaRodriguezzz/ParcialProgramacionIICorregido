
package biblioteca;

import java.util.ArrayList;


class Biblioteca {
    private ArrayList<Publicacion> publicaciones;
    
    public Biblioteca(){
        publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion p) throws PublicacionDuplicadaException {
        verificarPublicacion(p);
        if(p!=null){
            publicaciones.add(p);
        }
    }
    
    public void eliminarPublicacion(Publicacion p){
        publicaciones.remove(p);
    }
    
    public void mostrarPublicaciones(){
        for(Publicacion p: publicaciones){
            p.mostrarInfo();
        }
    }
    
    public void verificarPublicacion(Publicacion p) throws PublicacionDuplicadaException{
        if(publicaciones.contains(p)){
            throw new PublicacionDuplicadaException();
        }
    }
    
    public void leerPublicaciones(){
        System.out.println("Se van a leer las siguientes publicaciones");
        for (Publicacion p: publicaciones){
            if(p instanceof Leible leible){
                leible.leer();
            }
            else {
                System.out.println(p.getTitulo() + " no es leible");
            
            }
        }
    }
}
